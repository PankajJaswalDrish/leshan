# webapp

The **leshan-bsserver-demo** webapp is based on [Vue.js](https://vuejs.org/).  
For more details you should refer to **leshan-server-demo** [README](https://github.com/eclipse/leshan/tree/master/leshan-server-demo/webapp/README.md). 